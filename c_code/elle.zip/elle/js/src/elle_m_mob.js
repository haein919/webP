// elle_m_mob.js

(function($){
  // jQuery start
  

  // jQuery end
 })(jQuery);
 